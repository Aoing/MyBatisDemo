package com.aoing.dao;

import com.aoing.bean.Student;

public interface StudentDao {
    void insertStudent(Student student);
}
